# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Cats',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=200)),
                ('favorate_color', models.CharField(max_length=200)),
                ('branch', models.CharField(max_length=200)),
                ('timings', models.DateTimeField(auto_now_add=True, verbose_name=b'timings')),
            ],
        ),
        migrations.CreateModel(
            name='Dogs',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=200)),
                ('favorate_animal', models.CharField(max_length=200)),
                ('sex', models.CharField(max_length=1, choices=[(b'M', b'MALE'), (b'F', b'FEMALE')])),
                ('assigned_animal', models.ForeignKey(to='polls.Cats')),
            ],
        ),
    ]
