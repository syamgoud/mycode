from django.db import models

# Create your models here.
from django.db import models
class Cats(models.Model):
    name= models.CharField(max_length=200)
    favorate_color= models.CharField(max_length=200)
    branch= models.CharField(max_length=200)
    timings= models.DateTimeField('timings',auto_now_add=True)
    def __str__(self):
        return self.name



class Dogs(models.Model):
    name= models.CharField(max_length=200)
    favorate_animal= models.CharField(max_length=200)
    Animal = (
        ('M', 'MALE'),
        ('F', 'FEMALE'),
    )
    sex= models.CharField(max_length=1, choices=Animal)
    assigned_animal= models.ForeignKey(Cats, on_delete=models.CASCADE)
    def __str__(self):
        return self.name
